<!DOCTYPE html>
<html lang="en">
<head>
    
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MKRQFSM');</script>
<!-- End Google Tag Manager -->    
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SLIET ROBOTICS & AUTOMATION</title>
<meta name="google-site-verification" content="PaLi8DgBmby__hlUZOuGdfg7zxL-6m-VZmM8wXBUfgA" />
<meta name="description" content="In today’s world, we deal with workshops and projects related to automation and Robotics, or we can say we have indulged our self to automation. In the world of automation, SRAS is slowly walking ahead. SRAS Society deals with the design, construction, operation, structural disposition, manufacture and application of robots. SRAS is an organization for the students of Sant Longowal Institute of Engineering and Technology that provides the resources to develop robots.">
<meta name="og:description" content="In today’s world, we deal with workshops and projects related to automation and Robotics, or we can say we have indulged our self to automation. In the world of automation, SRAS is slowly walking ahead. SRAS Society deals with the design, construction, operation, structural disposition, manufacture and application of robots. SRAS is an organization for the students of Sant Longowal Institute of Engineering and Technology that provides the resources to develop robots.">
<meta name="author" content="">

<!-- Favicons
    ================================================== -->
<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">

<!-- Stylesheet
    ================================================== -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/nivo-lightbox.css">
<link rel="stylesheet" type="text/css" href="css/nivo-lightbox/default.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800,900" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MKRQFSM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Navigation
    ==========================================-->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" >
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="#page-top">
	  <img height="85" width="85" style="margin: -33px 0px" src="img/logo.png"   ></a>
	  </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#about" class="page-scroll">About</a></li>
                <li><a href="#testimonials" class="page-scroll">Achievements</a></li>
        <li><a href="#team" class="page-scroll">Team</a></li>
        <li><a href="#contact" class="page-scroll">Contact</a></li>
		
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
</nav>
<!-- Header -->
<header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 intro-text">
            <h1>SLIET ROBOTIC & AUTOMATION SOCIETY<span></span></h1>
            <p>THRIVE TO INNOVATE</p>
            <a href="#about" class="btn btn-custom btn-lg page-scroll">Learn More</a> </div>
        </div>
      </div>
    </div>
  </div>
</header>

<!-- About Section -->
<div id="about">
  <div class="container">
    
	<div class="row">
      <div class="col-xs-12 col-md-6"> <img src="img/about.jpg" class="img-responsive" alt=""> </div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
		<h2>About SLIET Robotics and Automation society (SRAS)</h2>
          <p>In today’s world, we deal with workshops and projects related to automation and Robotics, or we can say we have indulged our self to automation. In the world of automation, SRAS is slowly walking ahead. SRAS Society deals with the design, construction, operation, structural disposition, manufacture and application of robots. SRAS is an organization for the students of Sant Longowal Institute of Engineering and Technology that provides the resources to develop robots.</p>
          <h3>Why Choose Us?</h3>
          <div class="list-style">
            <div class="col-lg-6 col-sm-6 col-xs-12">
              <ul>
                <li>Innovations</li>
                <li>Workshops</li>
                <li>Projects</li>
                <li>IoT</li>
              </ul>
            </div>
            
          </div>
		  
        </div>
		
      </div>
    </div>
	<br>
	<div class="row">
      <div class="col-xs-12 col-md-6"> 
	  <div class="about-text">
		
		  <h2>Our Motto</h2>
          <p>To use technology or methods that provide automatic inspection, process control, and robot guidance. Automation surrounds a large number of technologies, software and hardware, integrated systems, actions, and methods. Our motto is to be the leader in the implementation of automation systems.</p>
         
        </div>
	  </div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
		
		  <h2>Our Vision</h2>
          <p>SRAS will integrate existing technologies in new ways so as to apply them to solve real-world problems. In the real world, automation is everywhere from planning the details of the requirements and project and then creating a solution. </p>
   		  
        </div>
		
      </div>
    </div>
  </div>
</div>
<!-- Services Section -->

<!-- Testimonials Section -->
<div id="testimonials">
  <div class="container">
    <div class="section-title text-center">
      <h2>Achievements</h2>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/sih.png" alt=""> </div>
          <div class="testimonial-content">
		  <div class="testimonial-meta"> - Smart India Hackathon | Hardware Edition | 2017-2018 </div>
            <p>"A national level event organised by Government of India for undergraduate students.
We were among the top 100 teams shortlisted for the Grand Finale after crossing various levels which included prototyping, designing and presenting the solution for a problem by one of the ministries. We were also nominated for top-40 start-ups in India."</p>
            
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/kweizar.jpg" alt=""> </div>
          <div class="testimonial-content">
            
            <div class="testimonial-meta"> Model Exhibition | Kweizar | 2018 </div>
			<p>"1st Position in working (Open Innovation) for making Smart Energy Meter."</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/rwc.jpg" alt=""> </div>
          <div class="testimonial-content">
            
            <div class="testimonial-meta"> World Robotics Championship (WRC) and the International Robotics League(IRL)  </div>
			<p>""</p>
          </div>
        </div>
      </div>
      <div class="row"> </div>
      <div class="col-md-4">
        <div class="testimonial">
          <div class="testimonial-image"> <img src="img/logo.png" alt=""> </div>
          <div class="testimonial-content">
            
            <div class="testimonial-meta"> Apart From this Team also represented the Institute in following Colleges and Government bodies: </div>
			<p>* National Academy of Science, Allahabad-1st Prize (Vikash Ranjan, Co-Head<br>
* SLIET Longowal-2nd & 3rd Prize<br>
* CGC, Chandigarh-3rd Prize<br>
* NIT, Jalandhar-Qualified for 2nd round<br>
* IIT BHU-Qualified for Final Round</p>
          </div>
        </div>
      </div>
      
      
    </div>
  </div>
</div>
<!-- Team Section -->
<div id="team" class="text-center">
  <div class="container">
    <div class="col-md-8 col-md-offset-2 section-title">
      <h2>Meet the Team</h2>
      <p>Together we can make difference</p>
	  <h1>Faculity Member(s)</h1>
    </div>
    <div id="row">
	 <div class="col-lg-6">
        <div class="thumbnail"> <img src="img/team/manmohansir.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Dr. Manmohan Singh</h4>
            <p>Associate Professor,<br>Electrical and Instrumentation Department.<br>SLIET</p>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="thumbnail"> <img src="img/team/asimsir.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Mr. Asim Ali Khan</h4>
            <p>Associate Professor,<br>Electrical and Instrumentation Department.<br>SLIET</p>
          </div>
        </div>
      </div>
     
      
    </div>
	<div class="col-md-8 col-md-offset-2 section-title">
      	  <h1>Student Advisor(s)</h1>
    </div>
	 <div id="row">
	 <div class="col-lg-6">
        <div class="thumbnail"> <img src="img/team/rahul.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Rahul Raj</h4>
            <p></p>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="thumbnail"> <img src="img/team/deeksha.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Deeksha Singh Katiyar</h4>
            <p></p>
          </div>
        </div>
      </div>   
	</div>
	<div class="col-md-8 col-md-offset-2 section-title">
      	  <h1>President & Vice President</h1>
    </div>
	<div id="row">
	 <div class="col-lg-6">
        <div class="thumbnail"> <img src="img/team/sudhanshu.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Sudhanshu Kumar</h4>
            <p>President</p>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="thumbnail"> <img src="img/team/harman.jpeg" alt="..." class="team-img">
          <div class="caption">
            <h4>Harmanjeet Singh</h4>
            <p>Vice President</p>
          </div>
        </div>
      </div>   
	</div>
	<div class="col-md-8 col-md-offset-2 section-title">
      	  <h1>Captain(s)</h1>
    </div>
	<div id="row">
	 <div class="col-lg-4 ">
        <div class="thumbnail"> <img src="img/team/ritika.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Ritika Negi</h4>
            <p>Captain Hardware</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="thumbnail"> <img src="img/team/shubham.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Shubham Mahajan</h4>
            <p>Captain Software</p>
          </div>
        </div>
      </div> 
	  <div class="col-lg-4">
        <div class="thumbnail"> <img src="img/team/sachin.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Sachin Korla</h4>
            <p>Captain Management</p>
          </div>
        </div>
      </div>   
	</div>
	<div class="col-md-8 col-md-offset-2 section-title"> 
      	  <h1>Executive Member(s)</h1>
    </div>
	 
	 <div id="row">
	 <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/navjot.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Navjot Jyoti</h4>
            <p>Hardware</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/manmohan.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Manmohan</h4>
            <p>Hardware</p>
          </div>
        </div>
      </div>
     
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/arun.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Arun Kumar</h4>
            <p>Hardware</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/prince.jpg" alt="..." class="team-img">
          <div class="caption">
            <h4>Prince</h4>
            <p>Software</p>
          </div>
        </div>
      </div>
    </div>
	
    </div>
  </div>
</div>
<!-- Contact Section -->
<div id="contact">
  <div class="container">
    <div class="col-md-8">
      <div class="row">
        <div class="section-title">
          <h2>Get In Touch</h2>
          <p>Please fill out the form below to send us an email and we will get back to you as soon as possible.</p>
        </div>
        <form name="sentMessage" id="contactForm" novalidate>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <input type="text" id="name" class="form-control" placeholder="Name" required="required">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <input type="email" id="email" class="form-control" placeholder="Email" required="required">
                <p class="help-block text-danger"></p>
              </div>
            </div>
          </div>
          <div class="form-group">
            <textarea name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
            <p class="help-block text-danger"></p>
          </div>
          <div id="success"></div>
          <button type="submit" class="btn btn-custom btn-lg">Send Message</button>
        </form>
      </div>
    </div>
    <div class="col-md-3 col-md-offset-1 contact-info">
      <div class="contact-item">
        <h3>Contact Info</h3>
        <p><span><i class="fa fa-map-marker"></i> Address</span>Sant Longowal Institute Of Engineering & Technology,<br>
          Longowal, Sangrur, <br>Punjab(148106)</p>
      </div>
      <div class="contact-item">
        <p><span><i class="fa fa-phone"></i> Phone</span> +91 8679625300</p>
        <p><span><i class="fa fa-phone"></i> Phone</span> +91 8679625300</p>
      </div>
	  <div class="contact-item">
        <p><span><i class="fa fa-envelope-o"></i> Email</span> </p>
      </div>
      <div class="contact-item">
        
      </div>
    </div>
    <div class="col-md-12">
      <div class="row">
        <div class="social">
          <ul>
            <li><a href="https://www.facebook.com/slietrobotics/"><i class="fa fa-facebook"></i></a></li>
			<li><a href="#"><i class="fa fa-instagram"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
            
	      </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Footer Section -->
<div id="footer">
  <div class="container text-center">
    <p>&copy; 2019 SLIET ROBOTICS AND AUTOMATION. Design by SRAS SOFTWARE TEAM</p>
  </div>
</div>
<script type="text/javascript" src="js/jquery.1.11.1.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/SmoothScroll.js"></script> 
<script type="text/javascript" src="js/nivo-lightbox.js"></script> 
<script type="text/javascript" src="js/jqBootstrapValidation.js"></script> 
<script type="text/javascript" src="js/contact_me.js"></script> 
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>